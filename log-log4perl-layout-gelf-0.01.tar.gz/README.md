Log::Log4perl::Layout::GELF (Log4perl in graylog format)
========================================================================

## Summary

[Log4perl]("http://search.cpan.org/~mschilli/Log-Log4perl-1.33/lib/Log/Log4perl.pm")
is great. [Graylog]("http://graylog2.org/") is awesome. This layout when used with 
Log::Log4perl::Appender::Socket allows you to log directly to graylog.

